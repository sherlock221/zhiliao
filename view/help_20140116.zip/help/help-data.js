var helpData = {


    "list": [

        {
            "questionName": "产品简介",
            "questionUrl": "./view/help/help-product.html"
        },

        {
            "questionName": "知了能做什么?",
            "questionUrl": "./view/help/知了能做什么.html"
        },

        {
            "questionName": "对比大众产品优势",
            "questionUrl": "./view/help/对比大众产品优势.html"
        },

        {
            "questionName": "使用知了客户端是否收费？",
            "questionUrl": "./view/help/使用知了客户端是否收费.html"
        },




        {
            "questionName": "新用户如何获取班级码",
            "questionUrl": "./view/help/新用户如何获取班级码.html"
        },
        {
            "questionName": "新用户如何通过班级码加入班级",
            "questionUrl": "./view/help/新用户如何通过班级码加入班级.html"
        },

        {
            "questionName": "我有班级码,如何加入班级?",
            "questionUrl": "./view/help/我有班级码,如何加入班级.html"
        },

        {
            "questionName": "我没有班级码,如何加入班级?",
            "questionUrl": "./view/help/我没有班级码,如何加入班级.html"
        },




        {
            "questionName": "老用户如何查看班级码",
            "questionUrl": "./view/help/老用户如何查看班级码.html"
        },

        {
            "questionName": "如何进入班群聊天？",
            "questionUrl": "./view/help/如何进入班群聊天.html"
        },

        {
            "questionName": "我可以与其他班级的教师或家长聊天吗？",
            "questionUrl": "./view/help/我可以与其他班级的教师或家长聊天吗.html"
        },

        {
            "questionName": "知了软件出现:“小知了累了”或“网络不给力”怎么办",
            "questionUrl": "./view/help/知了软件出现小知了累了.html"
        },




        {
            "questionName": "在知了客户端上发布的消息能显示在电脑网页上吗？",
            "questionUrl": "./view/help/在知了客户端上发布的消息能显示在电脑网页上吗.html"
        },
        {
            "questionName": "如何查看谁给我点赞了？",
            "questionUrl": "./view/help/如何查看谁给我点赞了.html"
        },
        {
            "questionName": "如何添加孩子？",
            "questionUrl": "./view/help/如何添加孩子.html"
        },
        {
            "questionName": "我可以与其他班群的老师或家长聊天吗？",
            "questionUrl": "./view/help/我可以与其他班群的老师或家长聊天吗.html"
        },


        {
            "questionName": "有网络的情况下，出现网络不给力异常提示是什么原因?",
            "questionUrl": "./view/help/有网络的情况下，出现网络不给力异常提示是什么原因.html"
        },





        {
            "questionName": "如何发布消息",
            "questionUrl": "./view/help/如何发布消息.html"
        },
        {
            "questionName": "如何查看我曾发过的消息",
            "questionUrl": "./view/help/如何查看我曾发过的消息.html"
        }

    ]
}